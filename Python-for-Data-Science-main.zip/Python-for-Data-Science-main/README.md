# Python-for-Data-Science
This repo contains some code for Python for data science, especially tailored towards NumPy, Pandas, and Matplotlib.
